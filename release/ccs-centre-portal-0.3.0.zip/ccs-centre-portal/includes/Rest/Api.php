<?php
namespace CCSPortal\Rest;

use CCSPortal\Install;
use CCSPortal\Data\Repo;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * REST API for the manager calculator.
 *
 * All subsidy maths is delegated to the shared CCS engine
 * (CCSCalculator\Includes\Calculator\CCSEngine) so the portal and the public
 * calculator can never diverge. This layer only resolves centre fees, prices
 * promotions on top of the engine result, and persists estimates.
 */
class Api {

    const NS = 'ccsp/v1';

    public function register() {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes() {
        register_rest_route(self::NS, '/calculate', [
            'methods'             => 'POST',
            'callback'            => [$this, 'calculate'],
            'permission_callback' => [$this, 'can_use'],
        ]);
        register_rest_route(self::NS, '/estimate', [
            'methods'             => 'POST',
            'callback'            => [$this, 'save_estimate'],
            'permission_callback' => [$this, 'can_use'],
        ]);
    }

    public function can_use() {
        return is_user_logged_in() && current_user_can('ccsp_use_portal');
    }

    /* ------------------------------------------------------------------ */

    public function calculate(WP_REST_Request $req) {
        if (!class_exists(CCSP_ENGINE_CLASS)) {
            return new WP_Error('ccsp_no_engine', 'The CCS calculation engine is unavailable. Activate the Child Care Subsidy Calculator plugin.', ['status' => 500]);
        }

        $centre_id = (int) $req->get_param('centre_id');
        if (!$centre_id || !Repo::can_access_centre($centre_id)) {
            return new WP_Error('ccsp_forbidden_centre', 'You do not have access to that centre.', ['status' => 403]);
        }
        $centre = Repo::centre($centre_id);
        $schedule = Repo::current_schedule($centre_id);
        $tiers = $schedule ? Repo::tiers($schedule->id) : [];
        $tier_rate = [];
        foreach ($tiers as $t) {
            $tier_rate[(int) $t->days] = (float) $t->daily_rate;
        }

        $rate_basis = in_array($req->get_param('rate_basis'), ['standard', 'weekly', 'windback'], true)
            ? $req->get_param('rate_basis') : 'standard';
        $period = in_array($req->get_param('period'), ['week', 'fortnight', 'month', 'year'], true)
            ? $req->get_param('period') : 'week';

        $knows_ccs = (bool) $req->get_param('knows_ccs');
        $income    = (float) $req->get_param('income');
        $activity  = (float) $req->get_param('activity_hours');
        $is_atsi   = (bool) $req->get_param('is_atsi');
        $withhold  = $req->get_param('withholding_pct');
        $withhold  = ($withhold === null || $withhold === '') ? 0.05 : (float) $withhold;

        // Build per-child engine input, resolving each child's daily fee.
        $children_in = [];
        $resolved = [];
        foreach ((array) $req->get_param('children') as $child) {
            $days1 = max(0, (int) ($child['days_week1'] ?? 0));
            $days2 = max(0, (int) ($child['days_week2'] ?? 0));
            $hours = (float) ($child['hours_per_day'] ?? 0);
            $dob   = sanitize_text_field($child['dob'] ?? '');

            $override = isset($child['fee_override']) && $child['fee_override'] !== '' ? (float) $child['fee_override'] : null;
            $fee = $override !== null
                ? $override
                : $this->resolve_daily_fee($schedule, $tier_rate, $rate_basis, max($days1, $days2));

            $children_in[] = [
                'dob'           => $dob,
                'care_type'     => 'cbdc',
                'hours_per_day' => $hours,
                'fee_per_day'   => $fee,
                'days_week1'    => $days1,
                'days_week2'    => $days2,
            ];
            $resolved[] = ['fee_per_day' => $fee];
        }

        $engine_input = [
            'knows_ccs'       => $knows_ccs,
            'income'          => $income,
            'activity_hours'  => $activity,
            'withholding_pct' => $withhold,
            'is_atsi'         => $is_atsi,
            'children'        => $children_in,
        ];
        if ($knows_ccs) {
            $known = (float) $req->get_param('known_pct'); // whole percent
            $engine_input['standard_pct'] = $known / 100;
            $engine_input['higher_pct']   = $known / 100;
        }

        $engine_class = CCSP_ENGINE_CLASS;
        $engine = new $engine_class(get_option('childcare_ccs_policy', []));
        $result = $engine->calculate($engine_input);

        $tf = $result['totals'];
        $totals_fortnight = [
            'fee'         => (float) $tf['fortnightFee'],
            'subsidy'     => (float) $tf['fortnightSub'],
            'gap'         => (float) $tf['outPocket'],
            'withholding' => (float) $tf['withholding'],
        ];

        // Promotion pricing — applied to the parent GAP, after subsidy.
        $promo = $this->price_promotion(
            (int) $req->get_param('promotion_id'),
            $centre_id,
            $totals_fortnight['gap']
        );

        // Scale to the requested display period.
        $mult = ['week' => 0.5, 'fortnight' => 1, 'month' => 26 / 12, 'year' => 26][$period];
        $totals_period = [
            'fee'     => $totals_fortnight['fee'] * $mult,
            'subsidy' => $totals_fortnight['subsidy'] * $mult,
            'gap'     => $totals_fortnight['gap'] * $mult,
        ];
        $gap_after_period = $totals_period['gap'];
        if ($promo && $promo['ongoing']) {
            $gap_after_period = max(0, $totals_period['gap'] - ($promo['weekly_saving'] / 0.5 * $mult));
        }

        // Per-child summary for the breakdown panel.
        $children_out = [];
        foreach ($result['children'] as $i => $c) {
            $children_out[] = [
                'age'          => (int) $c['age'],
                'feePerDay'    => (float) $c['feePerDay'],
                'fortnightFee' => (float) $c['fortnightFee'],
                'fortnightSub' => (float) $c['fortnightSub'],
                'gap'          => (float) $c['outPocket'],
                'ccs_pct'      => round($c['ccs_pct'] * 100, 2),
                'isHigher'     => (bool) $c['isHigherCCS'],
                'hourlyCap'    => (float) $c['hourlyCap'],
            ];
        }

        return new WP_REST_Response([
            'ok'     => true,
            'centre' => [
                'id'     => (int) $centre->id,
                'name'   => $centre->name,
                'code'   => $centre->code,
            ],
            'ccs' => [
                'standard_pct'          => round($result['standard_pct'] * 100, 2),
                'higher_pct'            => round($result['higher_pct'] * 100, 2),
                'hours_per_fortnight'   => (int) $result['ccs_hours_per_fortnight'],
            ],
            'children'         => $children_out,
            'totals_fortnight' => $totals_fortnight,
            'period'           => $period,
            'totals_period'    => $totals_period,
            'promo'            => $promo,
            'net_period_gap'   => $gap_after_period,
        ], 200);
    }

    /**
     * Resolve a single day's fee from the centre schedule.
     */
    private function resolve_daily_fee($schedule, array $tier_rate, $basis, $days) {
        if (!$schedule) {
            return 0.0;
        }
        if ($basis === 'weekly')   { return (float) $schedule->weekly_rate; }
        if ($basis === 'windback') { return (float) $schedule->windback_rate; }
        // Standard: use the day-tier rate if one exists for this day count, else full fee.
        if ($days >= 3 && isset($tier_rate[$days])) {
            return (float) $tier_rate[$days];
        }
        return (float) $schedule->full_daily_fee;
    }

    /**
     * Price a promotion against the fortnightly gap.
     * CCS is always computed on the gross fee; promotions only reduce the gap.
     *
     * @return array|null
     */
    private function price_promotion($promo_id, $centre_id, $fortnight_gap) {
        if (!$promo_id) {
            return null;
        }
        // Only allow promotions actually valid for this centre.
        $valid = false;
        foreach (Repo::promotions_for_centre($centre_id) as $p) {
            if ((int) $p->id === (int) $promo_id) {
                $promo = $p;
                $valid = true;
                break;
            }
        }
        if (!$valid) {
            return null;
        }

        $weekly_gap = $fortnight_gap / 2;
        $value = (float) $promo->value;
        $ongoing = false;
        $weekly_saving = 0.0;
        $total_value = 0.0;
        $desc = '';

        switch ($promo->unit) {
            case 'weeks': // N weeks of gap waived (one-time value)
                $total_value = $value * $weekly_gap;
                $desc = rtrim(rtrim(number_format($value, 2), '0'), '.') . ' weeks free';
                break;
            case 'percent': // ongoing % off the gap
                $ongoing = true;
                $weekly_saving = $weekly_gap * ($value / 100);
                $total_value = $weekly_saving; // per week
                $desc = rtrim(rtrim(number_format($value, 2), '0'), '.') . '% off gap';
                break;
            case 'amount': // ongoing $ off the gap, per week
                $ongoing = true;
                $weekly_saving = min($weekly_gap, $value);
                $total_value = $weekly_saving;
                $desc = '$' . number_format($value, 2) . ' off weekly gap';
                break;
        }

        return [
            'id'            => (int) $promo->id,
            'name'          => $promo->name,
            'type'          => $promo->type,
            'unit'          => $promo->unit,
            'description'   => $desc,
            'ongoing'       => $ongoing,
            'weekly_saving' => round($weekly_saving, 2),
            'total_value'   => round($total_value, 2),
        ];
    }

    /* ------------------------------------------------------------------ */

    public function save_estimate(WP_REST_Request $req) {
        global $wpdb;
        $centre_id = (int) $req->get_param('centre_id');
        if (!$centre_id || !Repo::can_access_centre($centre_id)) {
            return new WP_Error('ccsp_forbidden_centre', 'You do not have access to that centre.', ['status' => 403]);
        }
        $inputs  = $req->get_param('inputs');
        $results = $req->get_param('results');

        $wpdb->insert(Install::table('calculations'), [
            'centre_id'    => $centre_id,
            'manager_id'   => get_current_user_id(),
            'parent_name'  => sanitize_text_field($req->get_param('parent_name')),
            'parent_email' => sanitize_email($req->get_param('parent_email')),
            'parent_phone' => sanitize_text_field($req->get_param('parent_phone')),
            'income'       => (float) $req->get_param('income'),
            'ccs_pct'      => (float) $req->get_param('ccs_pct'),
            'promotion_id' => (int) $req->get_param('promotion_id'),
            'inputs_json'  => wp_json_encode($inputs),
            'results_json' => wp_json_encode($results),
            'status'       => 'new',
            'created_at'   => current_time('mysql'),
        ]);

        return new WP_REST_Response(['ok' => true, 'id' => (int) $wpdb->insert_id], 201);
    }
}
