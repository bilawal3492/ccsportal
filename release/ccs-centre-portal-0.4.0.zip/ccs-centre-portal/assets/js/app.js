/* Centre CCS Portal — React SaaS app (React 18 + htm, no build step).
 * Data comes from the WordPress REST API, scoped server-side by role. */
(function () {
	'use strict';
	var CFG = window.CCSP_APP || {};
	var React = window.React, ReactDOM = window.ReactDOM;
	if (!React || !ReactDOM || !window.htm) { return; }
	var html = window.htm.bind(React.createElement);
	var useState = React.useState, useEffect = React.useEffect, useCallback = React.useCallback;

	function money(n) {
		return '$' + (Math.round((n || 0) * 100) / 100).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
	}
	function api(path, opts) {
		opts = opts || {};
		return fetch(CFG.root + path, {
			method: opts.method || 'GET',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.nonce },
			body: opts.body ? JSON.stringify(opts.body) : undefined
		}).then(function (r) { return r.json(); });
	}
	var STATUS_CLASS = { new: 'st-new', contacted: 'st-contacted', enrolled: 'st-enrolled', lost: 'st-lost' };

	/* ---------------- KPI ---------------- */
	function Kpi(props) {
		return html`<div class="kpi"><span class="kpi-n">${props.value}</span><span class="kpi-l">${props.label}</span></div>`;
	}

	/* ---------------- Dashboard ---------------- */
	function Dashboard(props) {
		var s = useState(null), data = s[0], setData = s[1];
		useEffect(function () { api('reports/summary').then(setData); }, []);
		if (!data) { return html`<div class="loading">Loading dashboard…</div>`; }
		var c = data.counts || {};
		return html`
			<div>
				<h1 class="page-h">Dashboard</h1>
				<div class="kpi-row">
					<${Kpi} label="Estimates" value=${data.total} />
					<${Kpi} label="Enrolled" value=${c.enrolled || 0} />
					<${Kpi} label="Conversion" value=${data.conversion + '%'} />
					<${Kpi} label="Est. annual fees" value=${money(data.annual_fees)} />
				</div>
				<div class="grid2">
					<div class="card">
						<h3>Lead pipeline</h3>
						<div class="pipe">
							${['new', 'contacted', 'enrolled', 'lost'].map(function (k) {
								return html`<div class="pipe-row" key=${k}><span class=${'dot ' + STATUS_CLASS[k]}></span><span class="pipe-lab">${k}</span><span class="pipe-n">${c[k] || 0}</span></div>`;
							})}
						</div>
					</div>
					<div class="card">
						<h3>Promotions used</h3>
						${(data.promotions_used && data.promotions_used.length)
							? data.promotions_used.map(function (p, i) { return html`<div class="pipe-row" key=${i}><span class="pipe-lab">${p.name}</span><span class="pipe-n">${p.count}</span></div>`; })
							: html`<p class="muted">No promotions applied yet.</p>`}
					</div>
				</div>
			</div>`;
	}

	/* ---------------- Estimates list ---------------- */
	function Estimates(props) {
		var st = useState([]), rows = st[0], setRows = st[1];
		var fs = useState('all'), filter = fs[0], setFilter = fs[1];
		var qs = useState(''), q = qs[0], setQ = qs[1];
		var ls = useState(true), loading = ls[0], setLoading = ls[1];

		var load = useCallback(function () {
			setLoading(true);
			var p = 'estimates?status=' + filter + (q ? '&search=' + encodeURIComponent(q) : '');
			api(p).then(function (d) { setRows(d.estimates || []); setLoading(false); });
		}, [filter, q]);
		useEffect(function () { load(); }, [filter]);

		return html`
			<div>
				<h1 class="page-h">Saved estimates</h1>
				<div class="toolbar">
					<div class="tabs">
						${['all', 'new', 'contacted', 'enrolled', 'lost'].map(function (k) {
							return html`<button key=${k} class=${'tab' + (filter === k ? ' active' : '')} onClick=${function () { setFilter(k); }}>${k}</button>`;
						})}
					</div>
					<div class="search">
						<input placeholder="Search name or email" value=${q} onInput=${function (e) { setQ(e.target.value); }}
							onKeyDown=${function (e) { if (e.key === 'Enter') { load(); } }} />
						<button class="btn" onClick=${load}>Search</button>
					</div>
				</div>
				${loading ? html`<div class="loading">Loading…</div>` : html`
					<div class="tablewrap"><table class="tbl">
						<thead><tr><th>Family</th><th>Centre</th><th>CCS</th><th class="num">Weekly gap</th><th>Status</th><th>Date</th></tr></thead>
						<tbody>
							${rows.length === 0 ? html`<tr><td colspan="6" class="empty">No estimates found.</td></tr>` : rows.map(function (r) {
								return html`<tr key=${r.id} class="rowlink" onClick=${function () { props.onOpen(r.id); }}>
									<td><strong>${r.parent_name || '—'}</strong><br/><span class="muted">${r.parent_email || ''}</span></td>
									<td>${r.centre || '—'}</td>
									<td>${r.ccs_pct}%</td>
									<td class="num">${money(r.weekly_gap)}</td>
									<td><span class=${'badge ' + (STATUS_CLASS[r.status] || '')}>${r.status}</span></td>
									<td class="muted">${(r.created_at || '').substring(0, 10)}</td>
								</tr>`;
							})}
						</tbody>
					</table></div>`}
			</div>`;
	}

	/* ---------------- Estimate detail ---------------- */
	function Detail(props) {
		var s = useState(null), d = s[0], setD = s[1];
		var ss = useState(''), saving = ss[0], setSaving = ss[1];
		useEffect(function () { api('estimates/' + props.id).then(setD); }, [props.id]);
		if (!d) { return html`<div class="loading">Loading…</div>`; }
		var res = d.results || {};
		var tf = res.totals_fortnight || {};
		function setStatus(v) {
			setSaving(v);
			api('estimates/' + d.id + '/status', { method: 'POST', body: { status: v } })
				.then(function () { setD(Object.assign({}, d, { status: v })); setSaving(''); });
		}
		return html`
			<div>
				<button class="link" onClick=${props.onBack}>← Back to estimates</button>
				<h1 class="page-h">${d.parent_name || 'Estimate #' + d.id}</h1>
				<div class="grid2">
					<div class="card">
						<h3>Family</h3>
						<dl class="dl">
							<div><dt>Email</dt><dd>${d.parent_email || '—'}</dd></div>
							<div><dt>Phone</dt><dd>${d.parent_phone || '—'}</dd></div>
							<div><dt>Centre</dt><dd>${d.centre || '—'}</dd></div>
							<div><dt>Income</dt><dd>${money(d.income)}</dd></div>
							<div><dt>CCS</dt><dd>${d.ccs_pct}%</dd></div>
							<div><dt>Created</dt><dd>${(d.created_at || '').substring(0, 16)}</dd></div>
						</dl>
					</div>
					<div class="card">
						<h3>Estimate (per fortnight)</h3>
						<dl class="dl">
							<div><dt>Gross fee</dt><dd>${money(tf.fee)}</dd></div>
							<div><dt>CCS subsidy</dt><dd class="good">−${money(tf.subsidy)}</dd></div>
							<div><dt>Out of pocket</dt><dd><strong>${money(tf.gap)}</strong></dd></div>
							${res.promo ? html`<div><dt>Promotion</dt><dd>${res.promo.name}</dd></div>` : null}
						</dl>
						<h3 style=${{ marginTop: '16px' }}>Status</h3>
						<div class="statusbtns">
							${['new', 'contacted', 'enrolled', 'lost'].map(function (k) {
								return html`<button key=${k} disabled=${saving === k}
									class=${'sbtn' + (d.status === k ? ' active ' + STATUS_CLASS[k] : '')}
									onClick=${function () { setStatus(k); }}>${k}</button>`;
							})}
						</div>
					</div>
				</div>
			</div>`;
	}

	/* ---------------- App shell ---------------- */
	function App() {
		var ms = useState(null), me = ms[0], setMe = ms[1];
		var vs = useState({ name: 'dashboard' }), view = vs[0], setView = vs[1];
		useEffect(function () { api('me').then(setMe); }, []);
		if (!me) { return html`<div class="ccsp-app-loading">Loading portal…</div>`; }

		var nav = [
			{ k: 'dashboard', label: 'Dashboard' },
			{ k: 'estimates', label: 'Saved estimates' }
		];
		var body;
		if (view.name === 'detail') {
			body = html`<${Detail} id=${view.id} onBack=${function () { setView({ name: 'estimates' }); }} />`;
		} else if (view.name === 'estimates') {
			body = html`<${Estimates} onOpen=${function (id) { setView({ name: 'detail', id: id }); }} />`;
		} else {
			body = html`<${Dashboard} />`;
		}

		return html`
			<div class="shell">
				<aside class="side">
					<div class="brand"><span class="mark"></span><div><strong>CCS Portal</strong><span>${me.is_super ? 'Super admin' : 'Centre manager'}</span></div></div>
					<nav>
						${nav.map(function (n) {
							return html`<button key=${n.k} class=${'navbtn' + (view.name === n.k || (n.k === 'estimates' && view.name === 'detail') ? ' active' : '')}
								onClick=${function () { setView({ name: n.k }); }}>${n.label}</button>`;
						})}
						${me.calculator_url ? html`<a class="navbtn" href=${me.calculator_url}>New calculation ↗</a>` : null}
						${me.is_super ? html`<a class="navbtn sub" href="/wp-admin/admin.php?page=ccs-portal-centres">Manage centres ↗</a><a class="navbtn sub" href="/wp-admin/admin.php?page=ccs-portal-promotions">Manage promotions ↗</a>` : null}
					</nav>
					<div class="who">${me.name}<span>${me.centres.length} centre${me.centres.length === 1 ? '' : 's'}</span></div>
				</aside>
				<main class="main">${body}</main>
			</div>`;
	}

	function boot() {
		var root = document.getElementById('ccsp-app-root');
		if (root) { ReactDOM.createRoot(root).render(html`<${App} />`); }
	}
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
})();
