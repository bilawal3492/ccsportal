/* Centre CCS Portal — standalone React admin (React 18 + htm, no build step).
 * Managers: Dashboard + Saved estimates (scoped).
 * Super admins: also Centres & fees, Promotions, Brands, Users — full CRUD.
 * All data via the WordPress REST API, scoped server-side by role. */
(function () {
	'use strict';
	var CFG = window.CCSP_APP || {};
	var React = window.React, ReactDOM = window.ReactDOM;
	if (!React || !ReactDOM || !window.htm) { return; }
	var html = window.htm.bind(React.createElement);
	var useState = React.useState, useEffect = React.useEffect, useCallback = React.useCallback;

	function money(n) { return '$' + (Math.round((n || 0) * 100) / 100).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
	function api(path, opts) {
		opts = opts || {};
		return fetch(CFG.root + path, {
			method: opts.method || 'GET', credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.nonce },
			body: opts.body ? JSON.stringify(opts.body) : undefined
		}).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); });
	}
	var STC = { new: 'st-new', contacted: 'st-contacted', enrolled: 'st-enrolled', lost: 'st-lost' };
	var F = React.Fragment;
	function Icon(p) {
		var n = p.name, inner = null;
		if (n === 'dashboard') { inner = html`<${F}><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><//>`; }
		else if (n === 'estimates') { inner = html`<${F}><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/><path d="M9 13h6M9 17h4"/><//>`; }
		else if (n === 'centres') { inner = html`<${F}><path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/><//>`; }
		else if (n === 'promotions') { inner = html`<${F}><path d="M20.6 13.4 12 22l-9-9V4a1 1 0 0 1 1-1h8l8.6 8.6a1.4 1.4 0 0 1 0 1.8Z"/><circle cx="7.5" cy="7.5" r="1.3"/><//>`; }
		else if (n === 'brands') { inner = html`<${F}><circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1"/><circle cx="12" cy="7.5" r="1"/><circle cx="16" cy="10" r="1"/><path d="M12 21a3 3 0 0 0 0-6 2 2 0 0 1-2-2 2 2 0 0 0-4 0"/><//>`; }
		else if (n === 'users') { inner = html`<${F}><circle cx="9" cy="8" r="3.5"/><path d="M3 21a6 6 0 0 1 12 0"/><path d="M16 5a3.5 3.5 0 0 1 0 7"/><path d="M18.5 21a6 6 0 0 0-3-5.2"/><//>`; }
		else if (n === 'doc') { inner = html`<${F}><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/><//>`; }
		else if (n === 'check') { inner = html`<path d="M20 6 9 17l-5-5"/>`; }
		else if (n === 'percent') { inner = html`<${F}><line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/><//>`; }
		else if (n === 'dollar') { inner = html`<${F}><line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/><//>`; }
		else if (n === 'plus') { inner = html`<${F}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/><//>`; }
		return html`<svg width=${p.size || 18} height=${p.size || 18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">${inner}</svg>`;
	}
	var SECTION_TITLE = { dashboard: 'Dashboard', estimates: 'Saved estimates', detail: 'Estimate', centres: 'Centres & fees', promotions: 'Promotions', brands: 'Brands', users: 'Users' };

	/* ---------------- Form primitives ---------------- */
	function Text(p) {
		return html`<label class=${'f' + (p.wide ? ' wide' : '')}><span>${p.label}</span>
			<input type=${p.type || 'text'} value=${p.value == null ? '' : p.value} placeholder=${p.placeholder || ''}
				min=${p.min} max=${p.max} step=${p.step} readOnly=${p.readOnly}
				onInput=${function (e) { p.onChange(e.target.value); }} /></label>`;
	}
	function Sel(p) {
		return html`<label class=${'f' + (p.wide ? ' wide' : '')}><span>${p.label}</span>
			<select value=${p.value == null ? '' : String(p.value)} onChange=${function (e) { p.onChange(e.target.value); }}>
				${p.options.map(function (o) { return html`<option key=${o[0]} value=${String(o[0])}>${o[1]}</option>`; })}
			</select></label>`;
	}
	function Area(p) {
		return html`<label class="f wide"><span>${p.label}</span>
			<textarea rows=${p.rows || 4} value=${p.value == null ? '' : p.value} placeholder=${p.placeholder || ''}
				onInput=${function (e) { p.onChange(e.target.value); }}></textarea></label>`;
	}
	function Checks(p) {
		return html`<div class="checks">${p.items.map(function (it) {
			var on = p.value.indexOf(it.id) !== -1;
			return html`<label key=${it.id} class="chk"><input type="checkbox" checked=${on}
				onChange=${function () { p.onChange(on ? p.value.filter(function (x) { return x !== it.id; }) : p.value.concat([it.id])); }} /> ${it.label}</label>`;
		})}</div>`;
	}
	function Actions(p) {
		return html`<div class="formactions">
			<button class="btn primary" disabled=${p.saving} onClick=${p.onSave}>${p.saving ? 'Saving…' : (p.saveLabel || 'Save')}</button>
			<button class="btn" onClick=${p.onCancel}>Cancel</button>
			${p.onDelete ? html`<button class="btn danger" onClick=${p.onDelete}>${p.deleteLabel || 'Delete'}</button>` : null}
			${p.error ? html`<span class="formerr">${p.error}</span>` : null}
		</div>`;
	}

	/* ---------------- Dashboard ---------------- */
	function Dashboard() {
		var s = useState(null), data = s[0], setData = s[1];
		useEffect(function () { api('reports/summary').then(function (r) { setData(r.body); }); }, []);
		if (!data) { return html`<div class="loading">Loading dashboard…</div>`; }
		var c = data.counts || {};
		return html`<div>
			<h1 class="page-h">Dashboard</h1>
			<div class="kpi-row">
				<div class="kpi"><div class="kpi-top"><span class="kpi-l">Estimates</span><span class="kpi-ic ic-blue"><${Icon} name="doc" /></span></div><span class="kpi-n">${data.total}</span></div>
				<div class="kpi"><div class="kpi-top"><span class="kpi-l">Enrolled</span><span class="kpi-ic ic-green"><${Icon} name="check" /></span></div><span class="kpi-n">${c.enrolled || 0}</span></div>
				<div class="kpi"><div class="kpi-top"><span class="kpi-l">Conversion</span><span class="kpi-ic ic-amber"><${Icon} name="percent" /></span></div><span class="kpi-n">${data.conversion}%</span></div>
				<div class="kpi"><div class="kpi-top"><span class="kpi-l">Est. annual fees</span><span class="kpi-ic ic-violet"><${Icon} name="dollar" /></span></div><span class="kpi-n">${money(data.annual_fees)}</span></div>
			</div>
			<div class="grid2">
				<div class="card"><h3>Lead pipeline</h3>
					${['new', 'contacted', 'enrolled', 'lost'].map(function (k) {
						return html`<div class="pipe-row" key=${k}><span class=${'dot ' + STC[k]}></span><span class="pipe-lab">${k}</span><span class="pipe-n">${c[k] || 0}</span></div>`;
					})}
				</div>
				<div class="card"><h3>Promotions used</h3>
					${(data.promotions_used && data.promotions_used.length)
						? data.promotions_used.map(function (p, i) { return html`<div class="pipe-row" key=${i}><span class="pipe-lab">${p.name}</span><span class="pipe-n">${p.count}</span></div>`; })
						: html`<p class="muted">No promotions applied yet.</p>`}
				</div>
			</div>
		</div>`;
	}

	/* ---------------- Estimates ---------------- */
	function Estimates(props) {
		var st = useState([]), rows = st[0], setRows = st[1];
		var fs = useState('all'), filter = fs[0], setFilter = fs[1];
		var qs = useState(''), q = qs[0], setQ = qs[1];
		var ls = useState(true), loading = ls[0], setLoading = ls[1];
		var load = useCallback(function () {
			setLoading(true);
			api('estimates?status=' + filter + (q ? '&search=' + encodeURIComponent(q) : '')).then(function (r) { setRows((r.body && r.body.estimates) || []); setLoading(false); });
		}, [filter, q]);
		useEffect(function () { load(); }, [filter]);
		return html`<div>
			<h1 class="page-h">Saved estimates</h1>
			<div class="toolbar">
				<div class="tabs">${['all', 'new', 'contacted', 'enrolled', 'lost'].map(function (k) {
					return html`<button key=${k} class=${'tab' + (filter === k ? ' active' : '')} onClick=${function () { setFilter(k); }}>${k}</button>`;
				})}</div>
				<div class="search"><input placeholder="Search name or email" value=${q} onInput=${function (e) { setQ(e.target.value); }}
					onKeyDown=${function (e) { if (e.key === 'Enter') { load(); } }} /><button class="btn" onClick=${load}>Search</button></div>
			</div>
			${loading ? html`<div class="loading">Loading…</div>` : html`<div class="tablewrap"><table class="tbl">
				<thead><tr><th>Family</th><th>Centre</th><th>CCS</th><th class="num">Weekly gap</th><th>Status</th><th>Date</th></tr></thead>
				<tbody>${rows.length === 0 ? html`<tr><td colspan="6" class="empty">No estimates found.</td></tr>` : rows.map(function (r) {
					return html`<tr key=${r.id} class="rowlink" onClick=${function () { props.onOpen(r.id); }}>
						<td><strong>${r.parent_name || '—'}</strong><br/><span class="muted">${r.parent_email || ''}</span></td>
						<td>${r.centre || '—'}</td><td>${r.ccs_pct}%</td><td class="num">${money(r.weekly_gap)}</td>
						<td><span class=${'badge ' + (STC[r.status] || '')}>${r.status}</span></td>
						<td class="muted">${(r.created_at || '').substring(0, 10)}</td></tr>`;
				})}</tbody></table></div>`}
		</div>`;
	}
	function Detail(props) {
		var s = useState(null), d = s[0], setD = s[1];
		var ss = useState(''), saving = ss[0], setSaving = ss[1];
		useEffect(function () { api('estimates/' + props.id).then(function (r) { setD(r.body); }); }, [props.id]);
		if (!d) { return html`<div class="loading">Loading…</div>`; }
		var res = d.results || {}, tf = res.totals_fortnight || {};
		function setStatus(v) { setSaving(v); api('estimates/' + d.id + '/status', { method: 'POST', body: { status: v } }).then(function () { setD(Object.assign({}, d, { status: v })); setSaving(''); }); }
		return html`<div>
			<button class="link" onClick=${props.onBack}>← Back to estimates</button>
			<h1 class="page-h">${d.parent_name || 'Estimate #' + d.id}</h1>
			<div class="grid2">
				<div class="card"><h3>Family</h3><dl class="dl">
					<div><dt>Email</dt><dd>${d.parent_email || '—'}</dd></div>
					<div><dt>Phone</dt><dd>${d.parent_phone || '—'}</dd></div>
					<div><dt>Centre</dt><dd>${d.centre || '—'}</dd></div>
					<div><dt>Income</dt><dd>${money(d.income)}</dd></div>
					<div><dt>CCS</dt><dd>${d.ccs_pct}%</dd></div>
					<div><dt>Created</dt><dd>${(d.created_at || '').substring(0, 16)}</dd></div>
				</dl></div>
				<div class="card"><h3>Estimate (per fortnight)</h3><dl class="dl">
					<div><dt>Gross fee</dt><dd>${money(tf.fee)}</dd></div>
					<div><dt>CCS subsidy</dt><dd class="good">−${money(tf.subsidy)}</dd></div>
					<div><dt>Out of pocket</dt><dd><strong>${money(tf.gap)}</strong></dd></div>
					${res.promo ? html`<div><dt>Promotion</dt><dd>${res.promo.name}</dd></div>` : null}
				</dl>
				<h3 style=${{ marginTop: '16px' }}>Status</h3>
				<div class="statusbtns">${['new', 'contacted', 'enrolled', 'lost'].map(function (k) {
					return html`<button key=${k} disabled=${saving === k} class=${'sbtn' + (d.status === k ? ' active ' + STC[k] : '')} onClick=${function () { setStatus(k); }}>${k}</button>`;
				})}</div></div>
			</div>
		</div>`;
	}

	/* ---------------- Centres & fees ---------------- */
	function CentresView() {
		var s = useState(null), data = s[0], setData = s[1];
		var es = useState(null), editing = es[0], setEditing = es[1]; // id | 'new' | null
		var load = useCallback(function () { api('admin/centres').then(function (r) { setData(r.body); }); }, []);
		useEffect(function () { load(); }, []);
		if (!data) { return html`<div class="loading">Loading centres…</div>`; }
		if (editing !== null) {
			return html`<${CentreForm} id=${editing === 'new' ? null : editing} brands=${data.brands}
				onSaved=${function (b) { setData(Object.assign({}, data, { centres: b.centres })); setEditing(null); }}
				onCancel=${function () { setEditing(null); }} />`;
		}
		return html`<div>
			<div class="page-head"><h1 class="page-h">Centres &amp; fees</h1><button class="btn primary" onClick=${function () { setEditing('new'); }}>+ Add centre</button></div>
			<div class="tablewrap"><table class="tbl">
				<thead><tr><th>Brand</th><th>Code</th><th>Centre</th><th class="num">Full daily</th><th class="num">Weekly</th><th class="num">WindBack</th><th>Status</th><th></th></tr></thead>
				<tbody>${data.centres.map(function (c) {
					return html`<tr key=${c.id}>
						<td><span class="cdot" style=${{ background: c.accent }}></span>${c.brand_name}</td>
						<td><code>${c.code}</code></td><td>${c.name}</td>
						<td class="num">${money(c.full_daily_fee)}</td><td class="num">${money(c.weekly_rate)}</td><td class="num">${money(c.windback_rate)}</td>
						<td><span class=${'badge ' + (c.status === 'active' ? 'st-enrolled' : 'st-lost')}>${c.status}</span></td>
						<td><button class="btn sm" onClick=${function () { setEditing(c.id); }}>Edit</button></td></tr>`;
				})}</tbody></table></div>
		</div>`;
	}
	function CentreForm(props) {
		var fs = useState(null), form = fs[0], setForm = fs[1];
		var ss = useState(false), saving = ss[0], setSaving = ss[1];
		var errs = useState(''), err = errs[0], setErr = errs[1];
		useEffect(function () {
			if (props.id) { api('admin/centres/' + props.id).then(function (r) { setForm(r.body); }); }
			else { setForm({ brand_id: props.brands[0] ? props.brands[0].id : 0, code: '', name: '', status: 'active', phone: '', email: '', address: '', book_tour_url: '', full_daily_fee: '', weekly_rate: '', windback_rate: '', casual_rate: '', effective_from: '', tiers: { 3: 5, 4: 5, 5: 10 } }); }
		}, [props.id]);
		if (!form) { return html`<div class="loading">Loading…</div>`; }
		function up(k, v) { setForm(Object.assign({}, form, (function () { var o = {}; o[k] = v; return o; })())); }
		function tier(d, v) { var t = Object.assign({}, form.tiers); t[d] = v; up('tiers', t); }
		function save() {
			if (!form.name || !form.code) { setErr('Code and name are required.'); return; }
			setSaving(true); setErr('');
			api('admin/centres', { method: 'POST', body: form }).then(function (r) {
				setSaving(false);
				if (r.ok && r.body.ok) { props.onSaved(r.body); } else { setErr((r.body && r.body.message) || 'Save failed.'); }
			});
		}
		var brandOpts = props.brands.map(function (b) { return [b.id, b.name]; });
		return html`<div>
			<button class="link" onClick=${props.onCancel}>← Back to centres</button>
			<h1 class="page-h">${props.id ? 'Edit centre' : 'New centre'}</h1>
			<div class="card"><h3>Centre details</h3><div class="formgrid">
				<${Sel} label="Brand" value=${form.brand_id} onChange=${function (v) { up('brand_id', parseInt(v, 10)); }} options=${brandOpts} />
				<${Text} label="Code" value=${form.code} onChange=${function (v) { up('code', v); }} />
				<${Text} label="Centre name" value=${form.name} onChange=${function (v) { up('name', v); }} />
				<${Sel} label="Status" value=${form.status} onChange=${function (v) { up('status', v); }} options=${[['active', 'Active'], ['inactive', 'Inactive']]} />
				<${Text} label="Phone" value=${form.phone} onChange=${function (v) { up('phone', v); }} />
				<${Text} label="Email" type="email" value=${form.email} onChange=${function (v) { up('email', v); }} />
				<${Text} wide=${true} label="Address" value=${form.address} onChange=${function (v) { up('address', v); }} />
				<${Text} wide=${true} label="Book-a-tour URL" type="url" value=${form.book_tour_url} onChange=${function (v) { up('book_tour_url', v); }} />
			</div></div>
			<div class="card"><h3>Current fees</h3><div class="formgrid">
				<${Text} label="Effective from" type="date" value=${form.effective_from} onChange=${function (v) { up('effective_from', v); }} />
				<${Text} label="Full daily fee ($)" type="number" step="0.01" value=${form.full_daily_fee} onChange=${function (v) { up('full_daily_fee', v); }} />
				<${Text} label="Weekly rate — per day ($)" type="number" step="0.01" value=${form.weekly_rate} onChange=${function (v) { up('weekly_rate', v); }} />
				<${Text} label="WindBack rate ($)" type="number" step="0.01" value=${form.windback_rate} onChange=${function (v) { up('windback_rate', v); }} />
				<${Text} label="Casual rate ($)" type="number" step="0.01" value=${form.casual_rate} onChange=${function (v) { up('casual_rate', v); }} />
			</div>
			<h3 style=${{ marginTop: '14px' }}>Day-attendance discount (%)</h3><div class="formgrid">
				${[3, 4, 5].map(function (d) { return html`<${Text} key=${d} label=${d + '-day discount (%)'} type="number" step="0.01" value=${form.tiers[d]} onChange=${function (v) { tier(d, v); }} />`; })}
			</div></div>
			<${Actions} saving=${saving} error=${err} onSave=${save} onCancel=${props.onCancel} />
		</div>`;
	}

	/* ---------------- Promotions ---------------- */
	function PromotionsView() {
		var s = useState(null), data = s[0], setData = s[1];
		var es = useState(null), editing = es[0], setEditing = es[1];
		var load = useCallback(function () { api('admin/promotions').then(function (r) { setData(r.body); }); }, []);
		useEffect(function () { load(); }, []);
		if (!data) { return html`<div class="loading">Loading promotions…</div>`; }
		if (editing !== null) {
			var current = editing === 'new' ? null : data.promotions.filter(function (p) { return p.id === editing; })[0];
			return html`<${PromotionForm} promo=${current} brands=${data.brands} centres=${data.centres} types=${data.promo_types}
				onSaved=${function (b) { setData(Object.assign({}, data, { promotions: b.promotions })); setEditing(null); }} onCancel=${function () { setEditing(null); }} />`;
		}
		return html`<div>
			<div class="page-head"><h1 class="page-h">Promotions</h1><button class="btn primary" onClick=${function () { setEditing('new'); }}>+ Add promotion</button></div>
			<div class="tablewrap"><table class="tbl">
				<thead><tr><th>Name</th><th>Type</th><th>Value</th><th>Window</th><th>Status</th><th></th></tr></thead>
				<tbody>${data.promotions.length === 0 ? html`<tr><td colspan="6" class="empty">No promotions yet.</td></tr>` : data.promotions.map(function (p) {
					var val = p.unit === 'percent' ? p.value + '%' : p.unit === 'amount' ? money(p.value) : p.value + ' wks';
					var win = (p.start_date || '…') + ' → ' + (p.end_date || '…');
					return html`<tr key=${p.id}><td><strong>${p.name}</strong></td><td>${(data.promo_types[p.type] || p.type)}</td><td>${val}</td>
						<td class="muted">${(p.start_date || p.end_date) ? win : 'Always'}</td>
						<td><span class=${'badge ' + (p.status === 'active' ? 'st-enrolled' : 'st-lost')}>${p.status}</span></td>
						<td><button class="btn sm" onClick=${function () { setEditing(p.id); }}>Edit</button></td></tr>`;
				})}</tbody></table></div>
		</div>`;
	}
	function PromotionForm(props) {
		var p = props.promo || { name: '', type: 'weeks_free', value: '', unit: 'weeks', start_date: '', end_date: '', eligibility: '', terms: '', stackable: 0, status: 'active', brand_ids: [], centre_ids: [] };
		var fs = useState(p), form = fs[0], setForm = fs[1];
		var ss = useState(false), saving = ss[0], setSaving = ss[1];
		var errs = useState(''), err = errs[0], setErr = errs[1];
		function up(k, v) { setForm(Object.assign({}, form, (function () { var o = {}; o[k] = v; return o; })())); }
		function save() {
			if (!form.name) { setErr('Name is required.'); return; }
			setSaving(true); setErr('');
			api('admin/promotions', { method: 'POST', body: Object.assign({}, form, { id: props.promo ? props.promo.id : 0 }) })
				.then(function (r) { setSaving(false); if (r.ok && r.body.ok) { props.onSaved(r.body); } else { setErr('Save failed.'); } });
		}
		function del() {
			if (!props.promo || !confirm('Delete this promotion?')) { return; }
			api('admin/promotions/' + props.promo.id, { method: 'DELETE' }).then(function (r) { if (r.ok) { props.onSaved(r.body); } });
		}
		var typeOpts = Object.keys(props.types).map(function (k) { return [k, props.types[k]]; });
		return html`<div>
			<button class="link" onClick=${props.onCancel}>← Back to promotions</button>
			<h1 class="page-h">${props.promo ? 'Edit promotion' : 'New promotion'}</h1>
			<div class="card"><h3>Offer</h3><div class="formgrid">
				<${Text} wide=${true} label="Name" value=${form.name} onChange=${function (v) { up('name', v); }} placeholder="e.g. 4 Weeks Free — Winter" />
				<${Sel} label="Type" value=${form.type} onChange=${function (v) { up('type', v); }} options=${typeOpts} />
				<${Text} label="Value" type="number" step="0.01" value=${form.value} onChange=${function (v) { up('value', v); }} />
				<${Sel} label="Unit" value=${form.unit} onChange=${function (v) { up('unit', v); }} options=${[['weeks', 'Weeks'], ['percent', 'Percent (%)'], ['amount', 'Dollars ($)']]} />
				<${Sel} label="Status" value=${form.status} onChange=${function (v) { up('status', v); }} options=${[['active', 'Active'], ['inactive', 'Inactive']]} />
				<${Text} label="Start date" type="date" value=${form.start_date} onChange=${function (v) { up('start_date', v); }} />
				<${Text} label="End date" type="date" value=${form.end_date} onChange=${function (v) { up('end_date', v); }} />
				<${Area} label="Eligibility notes (internal)" rows=${2} value=${form.eligibility} onChange=${function (v) { up('eligibility', v); }} />
				<${Area} label="Terms & conditions (shown to the family)" rows=${7} value=${form.terms} onChange=${function (v) { up('terms', v); }} />
			</div></div>
			<div class="card"><h3>Where it applies</h3><p class="muted" style=${{ marginTop: '-6px', marginBottom: '10px' }}>Leave all unticked for a group-wide offer.</p>
				<div class="grid2">
					<div><strong class="mini">Brands</strong><${Checks} value=${form.brand_ids} onChange=${function (v) { up('brand_ids', v); }} items=${props.brands.map(function (b) { return { id: b.id, label: b.name }; })} /></div>
					<div><strong class="mini">Centres</strong><div class="scrollbox"><${Checks} value=${form.centre_ids} onChange=${function (v) { up('centre_ids', v); }} items=${props.centres.map(function (c) { return { id: c.id, label: c.brand_name + ' — ' + c.name }; })} /></div></div>
				</div>
			</div>
			<${Actions} saving=${saving} error=${err} onSave=${save} onCancel=${props.onCancel} onDelete=${props.promo ? del : null} />
		</div>`;
	}

	/* ---------------- Brands ---------------- */
	function BrandsView() {
		var s = useState(null), list = s[0], setList = s[1];
		useEffect(function () { api('admin/brands').then(function (r) { setList(r.body.brands); }); }, []);
		if (!list) { return html`<div class="loading">Loading brands…</div>`; }
		return html`<div><h1 class="page-h">Brands</h1>
			${list.map(function (b) { return html`<${BrandCard} key=${b.id} brand=${b} onSaved=${function (r) { setList(r.brands); }} />`; })}
		</div>`;
	}
	function BrandCard(props) {
		var fs = useState(props.brand), form = fs[0], setForm = fs[1];
		var ss = useState(false), saving = ss[0], setSaving = ss[1];
		function up(k, v) { setForm(Object.assign({}, form, (function () { var o = {}; o[k] = v; return o; })())); }
		function save() { setSaving(true); api('admin/brands', { method: 'POST', body: form }).then(function (r) { setSaving(false); if (r.ok) { props.onSaved(r.body); } }); }
		return html`<div class="card"><h3><span class="cdot" style=${{ background: form.accent_color }}></span>${form.name} <code>${form.code}</code></h3>
			<div class="formgrid">
				<${Text} label="Name" value=${form.name} onChange=${function (v) { up('name', v); }} />
				<${Text} label="Accent colour" value=${form.accent_color} onChange=${function (v) { up('accent_color', v); }} placeholder="#df7a2c" />
				<${Text} wide=${true} label="Logo URL" type="url" value=${form.logo_url} onChange=${function (v) { up('logo_url', v); }} />
				<${Text} label="Email from name" value=${form.email_from_name} onChange=${function (v) { up('email_from_name', v); }} />
				<${Text} label="Email from address" type="email" value=${form.email_from_address} onChange=${function (v) { up('email_from_address', v); }} />
			</div>
			<div class="formactions"><button class="btn primary" disabled=${saving} onClick=${save}>${saving ? 'Saving…' : 'Save ' + form.code}</button></div>
		</div>`;
	}

	/* ---------------- Users ---------------- */
	function UsersView() {
		var s = useState(null), data = s[0], setData = s[1];
		var load = useCallback(function () { api('admin/users').then(function (r) { setData(r.body); }); }, []);
		useEffect(function () { load(); }, []);
		if (!data) { return html`<div class="loading">Loading users…</div>`; }
		var centreItems = data.centres.map(function (c) { return { id: c.id, label: c.code }; });
		function remove(id) { if (confirm('Remove Centre Manager access for this user?')) { api('admin/managers/' + id, { method: 'DELETE' }).then(function (r) { setData(Object.assign({}, data, r.body)); }); } }
		return html`<div>
			<h1 class="page-h">Users</h1>
			<div class="grid2">
				<div class="card"><h3>Centre managers</h3>
					${data.managers.length === 0 ? html`<p class="muted">No managers yet.</p>` : data.managers.map(function (m) {
						return html`<${ManagerRow} key=${m.id} m=${m} centreItems=${centreItems} onSaved=${function (b) { setData(Object.assign({}, data, b)); }} onRemove=${function () { remove(m.id); }} />`;
					})}
				</div>
				<div><${AssignForm} data=${data} centreItems=${centreItems} onSaved=${function (b) { setData(Object.assign({}, data, b)); }} /></div>
			</div>
		</div>`;
	}
	function ManagerRow(props) {
		var m = props.m;
		var es = useState(false), open = es[0], setOpen = es[1];
		var cs = useState(m.centre_ids), sel = cs[0], setSel = cs[1];
		var ss = useState(false), saving = ss[0], setSaving = ss[1];
		function save() { setSaving(true); api('admin/managers', { method: 'POST', body: { user_id: m.id, centre_ids: sel } }).then(function (r) { setSaving(false); setOpen(false); if (r.ok) { props.onSaved(r.body); } }); }
		var codes = props.centreItems.filter(function (c) { return m.centre_ids.indexOf(c.id) !== -1; }).map(function (c) { return c.label; }).join(', ');
		return html`<div class="mrow">
			<div class="mrow-top"><div><strong>${m.name}</strong><br/><span class="muted">${m.email}</span></div>
				<div><button class="btn sm" onClick=${function () { setOpen(!open); }}>${open ? 'Close' : 'Edit'}</button> <button class="btn sm danger" onClick=${props.onRemove}>Remove</button></div></div>
			<div class="muted mrow-centres">${codes || 'No centres'}</div>
			${open ? html`<div class="mrow-edit"><${Checks} value=${sel} onChange=${setSel} items=${props.centreItems} />
				<button class="btn primary sm" disabled=${saving} onClick=${save}>${saving ? 'Saving…' : 'Save centres'}</button></div>` : null}
		</div>`;
	}
	function AssignForm(props) {
		var mode = useState('assign'), tab = mode[0], setTab = mode[1];
		// Assign existing
		var us = useState(0), userId = us[0], setUserId = us[1];
		var cs = useState([]), sel = cs[0], setSel = cs[1];
		// Create new
		var ns = useState({ name: '', email: '', centre_ids: [] }), nf = ns[0], setNf = ns[1];
		var ss = useState(false), saving = ss[0], setSaving = ss[1];
		var errs = useState(''), err = errs[0], setErr = errs[1];
		var existingIds = props.data.managers.map(function (m) { return m.id; });
		var userOpts = [[0, '— Select a user —']].concat(props.data.assignable.filter(function (u) { return existingIds.indexOf(u.id) === -1; }).map(function (u) { return [u.id, u.name + ' (' + u.email + ')']; }));
		function assign() {
			if (!userId) { setErr('Choose a user.'); return; }
			setSaving(true); setErr('');
			api('admin/managers', { method: 'POST', body: { user_id: userId, centre_ids: sel } }).then(function (r) { setSaving(false); if (r.ok) { setUserId(0); setSel([]); props.onSaved(r.body); } });
		}
		function create() {
			if (!nf.email) { setErr('Email is required.'); return; }
			setSaving(true); setErr('');
			api('admin/users/create', { method: 'POST', body: nf }).then(function (r) { setSaving(false); if (r.ok && r.body.ok) { setNf({ name: '', email: '', centre_ids: [] }); props.onSaved(r.body); } else { setErr((r.body && r.body.message) || 'Could not create user.'); } });
		}
		return html`<div class="card"><h3>Add a manager</h3>
			<div class="tabs mini2"><button class=${'tab' + (tab === 'assign' ? ' active' : '')} onClick=${function () { setTab('assign'); }}>Existing user</button><button class=${'tab' + (tab === 'create' ? ' active' : '')} onClick=${function () { setTab('create'); }}>New user</button></div>
			${tab === 'assign' ? html`<div>
				<${Sel} label="User" value=${userId} onChange=${function (v) { setUserId(parseInt(v, 10)); }} options=${userOpts} />
				<strong class="mini">Centres</strong><div class="scrollbox"><${Checks} value=${sel} onChange=${setSel} items=${props.centreItems} /></div>
				<div class="formactions"><button class="btn primary" disabled=${saving} onClick=${assign}>${saving ? 'Saving…' : 'Assign manager'}</button>${err ? html`<span class="formerr">${err}</span>` : null}</div>
			</div>` : html`<div>
				<${Text} label="Full name" value=${nf.name} onChange=${function (v) { setNf(Object.assign({}, nf, { name: v })); }} />
				<${Text} label="Email" type="email" value=${nf.email} onChange=${function (v) { setNf(Object.assign({}, nf, { email: v })); }} />
				<strong class="mini">Centres</strong><div class="scrollbox"><${Checks} value=${nf.centre_ids} onChange=${function (v) { setNf(Object.assign({}, nf, { centre_ids: v })); }} items=${props.centreItems} /></div>
				<p class="muted mini">The new user receives an email to set their password.</p>
				<div class="formactions"><button class="btn primary" disabled=${saving} onClick=${create}>${saving ? 'Creating…' : 'Create manager'}</button>${err ? html`<span class="formerr">${err}</span>` : null}</div>
			</div>`}
		</div>`;
	}

	/* ---------------- App shell ---------------- */
	function App() {
		var ms = useState(null), me = ms[0], setMe = ms[1];
		var vs = useState({ name: 'dashboard' }), view = vs[0], setView = vs[1];
		useEffect(function () { api('me').then(function (r) { setMe(r.body); }); }, []);
		if (!me) { return html`<div class="ccsp-app-loading">Loading portal…</div>`; }

		var groups = [{ title: 'Overview', items: [{ k: 'dashboard', label: 'Dashboard', icon: 'dashboard' }, { k: 'estimates', label: 'Saved estimates', icon: 'estimates' }] }];
		if (me.is_super) {
			groups.push({ title: 'Manage', items: [{ k: 'centres', label: 'Centres & fees', icon: 'centres' }, { k: 'promotions', label: 'Promotions', icon: 'promotions' }, { k: 'brands', label: 'Brands', icon: 'brands' }, { k: 'users', label: 'Users', icon: 'users' }] });
		}

		var body;
		switch (view.name) {
			case 'detail': body = html`<${Detail} id=${view.id} onBack=${function () { setView({ name: 'estimates' }); }} />`; break;
			case 'estimates': body = html`<${Estimates} onOpen=${function (id) { setView({ name: 'detail', id: id }); }} />`; break;
			case 'centres': body = html`<${CentresView} />`; break;
			case 'promotions': body = html`<${PromotionsView} />`; break;
			case 'brands': body = html`<${BrandsView} />`; break;
			case 'users': body = html`<${UsersView} />`; break;
			default: body = html`<${Dashboard} />`;
		}
		var activeKey = view.name === 'detail' ? 'estimates' : view.name;
		var initials = (me.name || '?').split(' ').map(function (w) { return w.charAt(0); }).join('').substring(0, 2).toUpperCase();

		return html`<div class="shell">
			<aside class="side">
				<div class="brand"><span class="mark"><${Icon} name="centres" size=${18} /></span><div><strong>CCS Portal</strong><span>${me.is_super ? 'Super admin' : 'Centre manager'}</span></div></div>
				<div class="navscroll">
				${groups.map(function (g) {
					return html`<div class="navgroup" key=${g.title}><span class="navtitle">${g.title}</span>
						${g.items.map(function (n) { return html`<button key=${n.k} class=${'navbtn' + (activeKey === n.k ? ' active' : '')} onClick=${function () { setView({ name: n.k }); }}><span class="navi"><${Icon} name=${n.icon} size=${17} /></span>${n.label}</button>`; })}
					</div>`;
				})}
				</div>
				<div class="who"><span class="uc-avatar dark">${initials}</span><div><strong>${me.name}</strong><span>${me.centres.length} centre${me.centres.length === 1 ? '' : 's'}</span></div></div>
			</aside>
			<div class="main">
				<header class="topbar">
					<h2 class="topbar-title">${SECTION_TITLE[view.name] || 'Portal'}</h2>
					<div class="topbar-actions">
						${me.calculator_url ? html`<a class="btn primary" href=${me.calculator_url}><span class="btni"><${Icon} name="plus" size=${16} /></span> New calculation</a>` : null}
						<div class="userchip"><span class="uc-avatar">${initials}</span><div class="uc-meta"><strong>${me.name}</strong><span>${me.is_super ? 'Super admin' : 'Manager'}</span></div></div>
					</div>
				</header>
				<div class="content">${body}</div>
			</div>
		</div>`;
	}

	function boot() { var root = document.getElementById('ccsp-app-root'); if (root) { ReactDOM.createRoot(root).render(html`<${App} />`); } }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
})();
