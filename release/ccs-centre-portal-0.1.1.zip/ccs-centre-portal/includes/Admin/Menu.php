<?php
namespace CCSPortal\Admin;

use CCSPortal\Install;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin menu + dashboard for the Centre CCS Portal.
 *
 * Phase 0 scope: a status dashboard proving the plugin, database, roles and
 * shared CCS engine are wired up, plus a read-only listing of the seeded
 * brands, centres and fee schedules. CRUD screens and the calculator app
 * arrive in later phases.
 */
class Menu {

    public function register() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function add_menu() {
        add_menu_page(
            'Centre CCS Portal',
            'CCS Portal',
            'ccsp_use_portal',
            'ccs-portal',
            [$this, 'render_dashboard'],
            'dashicons-building',
            26
        );
        add_submenu_page('ccs-portal', 'Dashboard', 'Dashboard', 'ccsp_use_portal', 'ccs-portal', [$this, 'render_dashboard']);
        add_submenu_page('ccs-portal', 'Centres & Fees', 'Centres & Fees', 'ccsp_view_records', 'ccs-portal-centres', [$this, 'render_centres']);
    }

    public function assets($hook) {
        if (strpos($hook, 'ccs-portal') === false) {
            return;
        }
        wp_enqueue_style('ccsp-admin', CCSP_URL . 'assets/css/admin.css', [], CCSP_VERSION);
    }

    /** Count helper. */
    private function count($basename) {
        global $wpdb;
        $t = Install::table($basename);
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM $t");
    }

    public function render_dashboard() {
        $engine_ok = class_exists(CCSP_ENGINE_CLASS);
        $brands    = $this->count('brands');
        $centres   = $this->count('centres');
        $promos    = $this->count('promotions');
        $calcs     = $this->count('calculations');
        ?>
        <div class="wrap ccsp-wrap">
            <h1 class="ccsp-title">Centre CCS Portal <span class="ccsp-ver">v<?php echo esc_html(CCSP_VERSION); ?></span></h1>
            <p class="ccsp-sub">Internal subsidy &amp; fee estimation tool across all centres — reusing the certified CCS engine, so the maths matches the public calculator exactly.</p>

            <div class="ccsp-stats">
                <div class="ccsp-stat"><span class="n"><?php echo esc_html($brands); ?></span><span class="l">Brands</span></div>
                <div class="ccsp-stat"><span class="n"><?php echo esc_html($centres); ?></span><span class="l">Centres</span></div>
                <div class="ccsp-stat"><span class="n"><?php echo esc_html($promos); ?></span><span class="l">Promotions</span></div>
                <div class="ccsp-stat"><span class="n"><?php echo esc_html($calcs); ?></span><span class="l">Saved estimates</span></div>
            </div>

            <h2>System status</h2>
            <table class="ccsp-status widefat">
                <tbody>
                    <tr>
                        <td>Shared CCS engine</td>
                        <td>
                            <?php if ($engine_ok) : ?>
                                <span class="ccsp-badge ok">Connected</span>
                                <code><?php echo esc_html(CCSP_ENGINE_CLASS); ?></code>
                            <?php else : ?>
                                <span class="ccsp-badge bad">Not found</span>
                                — activate <em>The Child Care Subsidy Calculator</em> plugin.
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Database schema</td>
                        <td><span class="ccsp-badge ok">v<?php echo esc_html(get_option('ccsp_db_version', '—')); ?></span> — <?php echo count(Install::TABLES); ?> tables installed</td>
                    </tr>
                    <tr>
                        <td>Centre Manager role</td>
                        <td><?php echo get_role(Install::ROLE_MANAGER) ? '<span class="ccsp-badge ok">Registered</span>' : '<span class="ccsp-badge bad">Missing</span>'; ?></td>
                    </tr>
                </tbody>
            </table>

            <h2>Build progress</h2>
            <ol class="ccsp-roadmap">
                <li class="done"><strong>Phase 0 — Foundation</strong> · plugin, database, roles, seeded brands/centres/fees, engine wiring</li>
                <li><strong>Phase 1 — Admin CRUD</strong> · manage centres, fees, promotions, email templates + audit log</li>
                <li><strong>Phase 2 — Calculator</strong> · one-screen manager app computing CCS via the shared engine over REST</li>
                <li><strong>Phase 3 — Outputs</strong> · branded email + server-rendered PDF estimates</li>
                <li><strong>Phase 4 — Reporting</strong> · leads, promotions used, revenue, conversion</li>
            </ol>
        </div>
        <?php
    }

    public function render_centres() {
        global $wpdb;
        $centres = Install::table('centres');
        $brands  = Install::table('brands');
        $sched   = Install::table('fee_schedules');

        $rows = $wpdb->get_results(
            "SELECT c.id, c.code, c.name, c.status, b.name AS brand, b.accent_color,
                    s.full_daily_fee, s.weekly_rate, s.windback_rate
             FROM $centres c
             LEFT JOIN $brands b ON b.id = c.brand_id
             LEFT JOIN $sched s ON s.centre_id = c.id AND s.is_current = 1
             ORDER BY b.name, c.code"
        );
        ?>
        <div class="wrap ccsp-wrap">
            <h1 class="ccsp-title">Centres &amp; Fees</h1>
            <p class="ccsp-sub">Seeded from the current fee schedule. Editing screens arrive in Phase 1 — for now this confirms the data model holds your day-rate, weekly and WindBack pricing per centre.</p>
            <table class="widefat striped ccsp-table">
                <thead>
                    <tr>
                        <th>Brand</th><th>Code</th><th>Centre</th>
                        <th class="num">Full daily</th><th class="num">Weekly (day)</th><th class="num">WindBack</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $r) : ?>
                        <tr>
                            <td><span class="ccsp-dot" style="background:<?php echo esc_attr($r->accent_color); ?>"></span><?php echo esc_html($r->brand); ?></td>
                            <td><code><?php echo esc_html($r->code); ?></code></td>
                            <td><?php echo esc_html($r->name); ?></td>
                            <td class="num">$<?php echo esc_html(number_format((float) $r->full_daily_fee, 2)); ?></td>
                            <td class="num">$<?php echo esc_html(number_format((float) $r->weekly_rate, 2)); ?></td>
                            <td class="num">$<?php echo esc_html(number_format((float) $r->windback_rate, 2)); ?></td>
                            <td><span class="ccsp-badge <?php echo $r->status === 'active' ? 'ok' : 'bad'; ?>"><?php echo esc_html(ucfirst($r->status)); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p class="ccsp-note"><strong>Note:</strong> the 3/4/5-day sibling-discount tiers are stored per centre. TFE and CKH suburb names are placeholders (their codes) until you confirm them — all editable in Phase 1.</p>
        </div>
        <?php
    }
}
