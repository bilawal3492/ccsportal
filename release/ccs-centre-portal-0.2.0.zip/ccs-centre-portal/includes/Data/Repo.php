<?php
namespace CCSPortal\Data;

use CCSPortal\Install;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Read helpers for portal data. Keeps SQL in one place so the controllers
 * and (later) the REST layer share exactly the same queries.
 */
class Repo {

    const MANAGER_META = 'ccsp_centre_ids';

    /* ---------------- Brands ---------------- */

    public static function brands() {
        global $wpdb;
        $t = Install::table('brands');
        return $wpdb->get_results("SELECT * FROM $t ORDER BY name");
    }

    public static function brand($id) {
        global $wpdb;
        $t = Install::table('brands');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
    }

    /** [id => name] for select boxes. */
    public static function brand_options() {
        $out = [];
        foreach (self::brands() as $b) {
            $out[(int) $b->id] = $b->name;
        }
        return $out;
    }

    /* ---------------- Centres ---------------- */

    public static function centres($only_active = false) {
        global $wpdb;
        $c = Install::table('centres');
        $b = Install::table('brands');
        $where = $only_active ? "WHERE c.status = 'active'" : '';
        return $wpdb->get_results(
            "SELECT c.*, b.name AS brand_name, b.accent_color
             FROM $c c LEFT JOIN $b b ON b.id = c.brand_id
             $where ORDER BY b.name, c.code"
        );
    }

    public static function centre($id) {
        global $wpdb;
        $t = Install::table('centres');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
    }

    /** [id => "Brand — Centre"] for select boxes. */
    public static function centre_options($only_active = false) {
        $out = [];
        foreach (self::centres($only_active) as $c) {
            $out[(int) $c->id] = trim(($c->brand_name ? $c->brand_name . ' — ' : '') . $c->name);
        }
        return $out;
    }

    /* ---------------- Fees ---------------- */

    public static function current_schedule($centre_id) {
        global $wpdb;
        $t = Install::table('fee_schedules');
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $t WHERE centre_id = %d AND is_current = 1 ORDER BY effective_from DESC LIMIT 1",
            $centre_id
        ));
    }

    public static function tiers($schedule_id) {
        global $wpdb;
        $t = Install::table('fee_tiers');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $t WHERE schedule_id = %d ORDER BY days",
            $schedule_id
        ));
    }

    /* ---------------- Promotions ---------------- */

    public static function promotions() {
        global $wpdb;
        $t = Install::table('promotions');
        return $wpdb->get_results("SELECT * FROM $t ORDER BY status, name");
    }

    public static function promotion($id) {
        global $wpdb;
        $t = Install::table('promotions');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d", $id));
    }

    /** Centre IDs a promotion is mapped to (empty = all centres in scope). */
    public static function promotion_centre_ids($promo_id) {
        global $wpdb;
        $t = Install::table('promotion_map');
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT centre_id FROM $t WHERE promotion_id = %d AND centre_id > 0",
            $promo_id
        ));
        return array_map('intval', $rows);
    }

    public static function promotion_brand_ids($promo_id) {
        global $wpdb;
        $t = Install::table('promotion_map');
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT brand_id FROM $t WHERE promotion_id = %d AND brand_id > 0",
            $promo_id
        ));
        return array_map('intval', $rows);
    }

    /** Human labels for promotion types. */
    public static function promo_types() {
        return [
            'weeks_free'       => 'Weeks Free',
            'windback'         => 'WindBack (returning family rate)',
            'returning_family' => 'Returning Family discount',
            'new_enrolment'    => 'New Enrolment discount',
            'custom'           => 'Custom / other',
        ];
    }

    /* ---------------- Managers ---------------- */

    /** WP users holding the Centre Manager role. */
    public static function managers() {
        return get_users(['role' => Install::ROLE_MANAGER, 'orderby' => 'display_name']);
    }

    /** Centre IDs assigned to a user. */
    public static function manager_centre_ids($user_id) {
        $ids = get_user_meta($user_id, self::MANAGER_META, true);
        return is_array($ids) ? array_map('intval', $ids) : [];
    }

    /** Users who could be assigned as managers (not already managers/admins excluded). */
    public static function assignable_users() {
        return get_users(['orderby' => 'display_name', 'number' => 500]);
    }
}
